# Copyright (c) 2006-2024 Broadcom. All Rights Reserved.
# Broadcom Confidential. The term "Broadcom" refers to Broadcom Inc.
# and/or its subsidiaries.

# ******* WARNING - AUTO GENERATED CODE - DO NOT EDIT *******

from pyVmomi.pbm import ExtendedElementDescription

from pyVmomi.vmodl import DynamicData

class DescriptiveValue(DynamicData):
   description: ExtendedElementDescription
   value: object
