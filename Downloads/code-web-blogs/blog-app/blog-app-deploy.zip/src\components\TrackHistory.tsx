"use client";

import { useEffect } from "react";

export default function TrackHistory({ post }: { post: any }) {
  useEffect(() => {
    try {
      const historyStr = localStorage.getItem("myblog_history");
      let history = historyStr ? JSON.parse(historyStr) : [];
      
      // Remove if already exists to push it to the top
      history = history.filter((p: any) => p.slug !== post.slug);
      
      // Add to front
      history.unshift({
        slug: post.slug,
        title: post.title,
        coverImage: post.coverImage,
        createdAt: new Date().toISOString()
      });
      
      // Keep only last 5
      if (history.length > 5) {
        history = history.slice(0, 5);
      }
      
      localStorage.setItem("myblog_history", JSON.stringify(history));
    } catch (error) {
      console.error("Lỗi khi lưu lịch sử đọc:", error);
    }
  }, [post]);

  return null; // Component không hiển thị gì cả
}
