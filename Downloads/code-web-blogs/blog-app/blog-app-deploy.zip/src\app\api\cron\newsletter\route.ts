import { NextResponse } from "next/server";
import connectDB from "@/lib/mongodb";
import Subscriber from "@/models/Subscriber";
import Post from "@/models/Post";
import Setting from "@/models/Setting";
import nodemailer from "nodemailer";

export async function GET(req: Request) {
  try {
    // Để bảo mật API này (để không ai cũng có thể gọi bừa), ta có thể kiểm tra một secret key trong header.
    // Ví dụ: req.headers.get("Authorization") === `Bearer ${process.env.CRON_SECRET}`
    
    await connectDB();

    // 1. Lấy danh sách Subscriber (active = true)
    const subscribers = await Subscriber.find({ active: true }).lean();
    if (subscribers.length === 0) {
      return NextResponse.json({ message: "No active subscribers" }, { status: 200 });
    }

    // 2. Lấy danh sách Top 3 bài viết nổi bật (hoặc mới nhất)
    const recentPosts = await Post.find({ status: "published" })
      .sort({ createdAt: -1 })
      .limit(3)
      .lean();

    if (recentPosts.length === 0) {
      return NextResponse.json({ message: "No new posts to send" }, { status: 200 });
    }

    const st = await Setting.findOne({ key: 'site_title' }).lean();
    const siteTitle = (st?.value as string) || "Tên Website";

    // 3. Tạo nội dung Email HTML
    const postsHtml = recentPosts.map((post: any) => `
      <div style="margin-bottom: 20px; padding: 15px; border: 1px solid #eee; border-radius: 8px;">
        <h3 style="margin-top: 0; color: #4f46e5;">
          <a href="${process.env.NEXTAUTH_URL || 'http://localhost:3000'}/posts/${post.slug}" style="text-decoration: none; color: #4f46e5;">
            ${post.title}
          </a>
        </h3>
        <p style="color: #666; font-size: 14px;">${post.excerpt || "Một bài viết mới vô cùng thú vị đang chờ bạn khám phá."}</p>
        <a href="${process.env.NEXTAUTH_URL || 'http://localhost:3000'}/posts/${post.slug}" style="display: inline-block; margin-top: 10px; padding: 8px 16px; background-color: #4f46e5; color: #fff; text-decoration: none; border-radius: 4px; font-weight: bold;">Đọc ngay</a>
      </div>
    `).join("");

    const htmlContent = `
      <div style="font-family: sans-serif; max-w: 600px; margin: 0 auto; color: #333;">
        <div style="background-color: #f1f5f9; padding: 20px; text-align: center; border-radius: 8px 8px 0 0;">
          <h2 style="margin: 0; color: #1e293b;">Bản tin ${siteTitle} Hàng Tuần</h2>
        </div>
        <div style="padding: 20px; border: 1px solid #e2e8f0; border-top: none;">
          <p>Xin chào,</p>
          <p>Tuần qua <strong>${siteTitle}</strong> có gì hot? Hãy cùng điểm lại những bài viết được quan tâm nhất nhé:</p>
          ${postsHtml}
          <p style="margin-top: 30px;">
            Chúc bạn một tuần mới nhiều năng lượng!<br/>
            Cảm ơn bạn đã đồng hành cùng ${siteTitle}.<br/>
            Nếu không muốn nhận email nữa, bạn có thể <a href="#" style="color: #94a3b8;">hủy đăng ký</a>.
          </p>
        </div>
      </div>
    `;

    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
      },
    });

    let successCount = 0;
    for (const sub of subscribers) {
      try {
        await transporter.sendMail({
          from: `"${siteTitle} Newsletter" <${process.env.EMAIL_USER}>`,
          to: sub.email,
          subject: `🔥 Top 3 Bài viết Nổi bật Tuần này từ ${siteTitle}`,
          html: htmlContent,
        });
        successCount++;
      } catch (err) {
        console.error(`Failed to send to ${sub.email}:`, err);
      }
    }

    return NextResponse.json({ message: `Newsletter sent successfully to ${successCount} subscribers` }, { status: 200 });
  } catch (error) {
    console.error("Cronjob Newsletter Error:", error);
    return NextResponse.json({ error: "Failed to send newsletter" }, { status: 500 });
  }
}
