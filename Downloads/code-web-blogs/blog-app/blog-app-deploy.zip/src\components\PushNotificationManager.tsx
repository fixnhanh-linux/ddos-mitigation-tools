"use client";

import { useState, useEffect } from 'react';
import { Bell, BellOff } from 'lucide-react';

const publicVapidKey = process.env.NEXT_PUBLIC_VAPID_KEY || "BP6AAegTzTUBbISSb-6K3KA5NeAzkqDj15Bj8op1tCfDKehahvH9UzkPAau47bGNyqR52i1X8GgrLoJulwzAa-w";

function urlBase64ToUint8Array(base64String: string) {
  const padding = '='.repeat((4 - base64String.length % 4) % 4);
  const base64 = (base64String + padding)
    .replace(/\-/g, '+')
    .replace(/_/g, '/');

  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);

  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

export default function PushNotificationManager() {
  const [isSupported, setIsSupported] = useState(false);
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [subscription, setSubscription] = useState<PushSubscription | null>(null);

  useEffect(() => {
    if ('serviceWorker' in navigator && 'PushManager' in window) {
      setIsSupported(true);
      registerServiceWorker();
    }
  }, []);

  async function registerServiceWorker() {
    const registration = await navigator.serviceWorker.register('/sw.js', {
      scope: '/',
      updateViaCache: 'none',
    });
    const sub = await registration.pushManager.getSubscription();
    if (sub) {
      setSubscription(sub);
      setIsSubscribed(true);
    }
  }

  async function subscribeToPush() {
    try {
      const registration = await navigator.serviceWorker.ready;
      const sub = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(publicVapidKey),
      });
      setSubscription(sub);
      setIsSubscribed(true);
      
      // Save to database
      await fetch('/api/push/subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(sub),
      });
      
    } catch (error) {
      console.error('Failed to subscribe:', error);
      alert('Không thể đăng ký nhận thông báo. Vui lòng cấp quyền trong trình duyệt.');
    }
  }

  async function unsubscribeFromPush() {
    try {
      const sub = await subscription?.unsubscribe();
      if (sub) {
        setIsSubscribed(false);
        setSubscription(null);
        // Note: should also delete from database in a complete implementation
      }
    } catch (error) {
      console.error('Failed to unsubscribe:', error);
    }
  }

  if (!isSupported) {
    return null;
  }

  return (
    <div className="flex items-center gap-2 mt-4 bg-slate-50 p-4 rounded-xl border border-slate-100">
      <div className={`p-2 rounded-lg ${isSubscribed ? 'bg-indigo-100 text-indigo-600' : 'bg-slate-200 text-slate-500'}`}>
        {isSubscribed ? <Bell size={20} /> : <BellOff size={20} />}
      </div>
      <div className="flex-1">
        <h4 className="font-semibold text-slate-800 text-sm">Nhận thông báo bài mới</h4>
        <p className="text-xs text-slate-500">Đừng bỏ lỡ những bài viết công nghệ hay nhất.</p>
      </div>
      <button 
        onClick={isSubscribed ? unsubscribeFromPush : subscribeToPush}
        className={`px-3 py-1.5 text-xs font-medium rounded-lg transition ${
          isSubscribed 
            ? 'bg-slate-200 text-slate-700 hover:bg-slate-300' 
            : 'bg-indigo-600 text-white hover:bg-indigo-700'
        }`}
      >
        {isSubscribed ? 'Hủy nhận' : 'Đăng ký ngay'}
      </button>
    </div>
  );
}
