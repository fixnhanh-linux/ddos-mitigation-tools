import Link from "next/link";

export default function TagsWidget() {
  const tags = [
    "Linux cơ bản", "Ubuntu", "Bash", "Security", "Ứng dụng", "CentOS", "PHP", 
    "Nginx", "Databases", "System tools", "MariaDB", "MySQL", "Storage", 
    "MongoDB", "Networking", "Suricata", "Debian", "AlmaLinux", "OpenLiteSpeed", 
    "Docker", "Kubernetes", "Rocky Linux", "Logging", "Monitoring", "CI/CD", 
    "WordPress", "LEMP", "VPN", "Apache", "Email Server"
  ];

  return (
    <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 shadow-sm border border-slate-100 dark:border-slate-700 transition-colors">
      <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-6">Theo chủ đề</h3>
      <div className="flex flex-wrap gap-2">
        {tags.map((tag) => (
          <Link 
            key={tag} 
            href={`/search?q=${encodeURIComponent(tag)}`}
            className="px-3 py-1.5 bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-md text-sm hover:bg-indigo-50 hover:text-indigo-600 dark:hover:bg-indigo-900/30 dark:hover:text-indigo-400 transition-colors"
          >
            {tag}
          </Link>
        ))}
      </div>
    </div>
  );
}
