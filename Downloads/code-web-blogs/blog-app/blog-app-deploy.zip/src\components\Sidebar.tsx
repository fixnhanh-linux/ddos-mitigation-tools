import connectDB from "@/lib/mongodb";
import Post from "@/models/Post";
import Setting from "@/models/Setting";
import Link from "next/link";
import Image from "next/image";
import { TrendingUp, ImageIcon } from "lucide-react";
import PremiumBanner from "@/components/PremiumBanner";
import RecentHistory from "@/components/RecentHistory";
import LeaderboardWidget from "@/components/LeaderboardWidget";
import DonationWidget from "@/components/DonationWidget";
import PushNotificationManager from "@/components/PushNotificationManager";
import TagsWidget from "@/components/TagsWidget";

export default async function Sidebar() {
  await connectDB();
  
  // Lấy 3 bài viết mới nhất (hoặc nổi bật)
  const trendingPosts = await Post.find({ published: true })
    .sort({ createdAt: -1 })
    .limit(4)
    .lean();

  // Kiểm tra cài đặt bật/tắt Paywall (Premium)
  const paywallSetting = await Setting.findOne({ key: "enable_paywall" }).lean();
  const isPaywallEnabled = paywallSetting ? paywallSetting.value : false;

  return (
    <aside className="space-y-8 w-full">
      {/* Donation Mini Widget */}
      <DonationWidget variant="mini" />

      {/* Widget 1: Trending Posts */}
      <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 shadow-sm border border-slate-100 dark:border-slate-700 transition-colors">
        <div className="flex items-center gap-2 mb-6">
          <TrendingUp className="text-indigo-600 dark:text-indigo-400" size={20} />
          <h3 className="text-lg font-bold text-slate-900 dark:text-white">Bài viết nổi bật</h3>
        </div>
        <div className="space-y-6">
          {trendingPosts.map((post: any, index: number) => (
            <Link key={post._id.toString()} href={`/posts/${post.slug}`} className="group flex gap-4 items-start">
              <div className="relative w-20 h-20 rounded-2xl overflow-hidden flex-shrink-0 bg-slate-100 dark:bg-slate-700">
                {post.coverImage && (post.coverImage.startsWith('http') || post.coverImage.startsWith('/')) ? (
                  <Image src={post.coverImage} alt={post.title} fill className="object-cover group-hover:scale-110 transition duration-500" />
                ) : (
                  <img src={post.coverImage || `https://picsum.photos/seed/${post._id}/200/200`} alt={post.title} className="w-full h-full object-cover group-hover:scale-110 transition duration-500" />
                )}
                <div className="absolute top-0 left-0 bg-indigo-600 text-white w-6 h-6 flex items-center justify-center text-xs font-bold rounded-br-lg z-10">
                  {index + 1}
                </div>
              </div>
              <div className="flex-1">
                <h4 className="font-bold text-slate-900 dark:text-white text-sm line-clamp-2 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition mb-1 leading-snug">
                  {post.title}
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400">{new Date(post.createdAt).toLocaleDateString("vi-VN")}</p>
              </div>
            </Link>
          ))}
        </div>
      </div>

      <div className="p-6">
          <p className="text-sm text-slate-600 mb-4 font-medium">Nhập email để nhận những bài viết công nghệ mới nhất hàng tuần.</p>
          <Link href="/media" className="flex items-center gap-2 text-sm text-indigo-600 font-medium mb-4 hover:underline">
            <ImageIcon size={16} /> Quản lý thư viện Media
          </Link>
          <form className="flex gap-2">
            <input type="email" placeholder="Địa chỉ Email..." className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
            <button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition font-medium text-sm whitespace-nowrap">Đăng ký</button>
          </form>
          
          <PushNotificationManager />
      </div>

      {/* Widget 1.2: Bảng phong thần */}
      <LeaderboardWidget />

      {/* Widget 1.3: Tag Cloud */}
      <TagsWidget />

      {/* Widget 1.5: Vừa xem gần đây (Client-side) */}
      <RecentHistory />

      {/* Widget 2: Banner Quảng cáo / Subscribe */}
      {isPaywallEnabled && <PremiumBanner />}
    </aside>
  );
}
