"use client";

import { useState, useRef, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Search, X } from "lucide-react";

export default function SearchInput() {
  const [isOpen, setIsOpen] = useState(false);
  const [query, setQuery] = useState("");
  const router = useRouter();
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      router.push(`/search?q=${encodeURIComponent(query.trim())}`);
      setIsOpen(false);
      setQuery("");
    }
  };

  if (!isOpen) {
    return (
      <button 
        onClick={() => setIsOpen(true)}
        className="text-slate-400 hover:text-indigo-600 transition p-2 rounded-full hover:bg-slate-50"
      >
        <Search size={20} />
      </button>
    );
  }

  return (
    <div className="absolute inset-0 bg-white/95 backdrop-blur z-50 flex items-center justify-center px-4">
      <div className="w-full max-w-3xl flex items-center gap-4">
        <form onSubmit={handleSubmit} className="flex-1 relative">
          <Search size={24} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Tìm kiếm bài viết, công nghệ..."
            className="w-full text-xl md:text-2xl bg-transparent border-none focus:ring-0 pl-14 pr-4 py-4 text-slate-900 placeholder:text-slate-300 font-medium"
          />
        </form>
        <button 
          onClick={() => setIsOpen(false)}
          className="p-3 text-slate-500 hover:bg-slate-100 rounded-full transition"
        >
          <X size={24} />
        </button>
      </div>
    </div>
  );
}
