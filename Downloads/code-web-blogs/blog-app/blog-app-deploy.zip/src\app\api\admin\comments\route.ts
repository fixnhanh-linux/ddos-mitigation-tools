import { NextResponse } from "next/server";
import connectDB from "@/lib/mongodb";
import Comment from "@/models/Comment";
import Post from "@/models/Post"; // needed for populate

export async function GET() {
  try {
    await connectDB();
    
    // Fetch all comments, sort by newest, populate post title
    const comments = await Comment.find()
      .populate({ path: 'post', select: 'title' })
      .sort({ createdAt: -1 })
      .lean();

    return NextResponse.json(comments);
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch comments for admin" }, { status: 500 });
  }
}
