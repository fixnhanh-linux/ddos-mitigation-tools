"use client";

import { useState, useEffect } from "react";
import { Coffee, CreditCard, Heart } from "lucide-react";

export default function DonationWidget({ variant = "default" }: { variant?: "default" | "mini" }) {
  const [settings, setSettings] = useState<any>(null);
  const [activeTab, setActiveTab] = useState<"bank" | "momo" | "coffee">("bank");
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetch('/api/settings?group=monetization')
      .then(res => res.json())
      .then(data => {
        setSettings(data);
        setIsLoading(false);
        // Set default active tab based on what is available
        if (data.donation_bank_id && data.donation_bank_account) setActiveTab("bank");
        else if (data.donation_momo) setActiveTab("momo");
        else if (data.donation_buymeacoffee) setActiveTab("coffee");
      })
      .catch(() => setIsLoading(false));
  }, []);

  if (isLoading || !settings || !settings.enable_donation) return null;

  const hasBank = !!(settings.donation_bank_id && settings.donation_bank_account);
  const hasMomo = !!settings.donation_momo;
  const hasCoffee = !!settings.donation_buymeacoffee;

  if (!hasBank && !hasMomo && !hasCoffee) return null;

  if (variant === "mini") {
    return (
      <div className="bg-gradient-to-br from-pink-50 to-orange-50 border border-pink-100 rounded-2xl p-5 mb-8">
        <div className="flex items-center gap-2 text-pink-600 mb-2">
          <Heart size={20} className="fill-pink-600" />
          <h3 className="font-bold text-lg">{settings.donation_title || "Ủng hộ tác giả"}</h3>
        </div>
        <p className="text-sm text-slate-600 mb-4">{settings.donation_message}</p>
        <div className="space-y-2">
          {hasBank && (
            <button onClick={() => { setActiveTab("bank"); document.getElementById('main-donation')?.scrollIntoView({ behavior: 'smooth' })}} className="w-full flex items-center justify-center gap-2 py-2 bg-white border border-pink-200 text-pink-700 rounded-lg hover:bg-pink-50 transition text-sm font-medium">
              <CreditCard size={16} /> Chuyển khoản (VietQR)
            </button>
          )}
          {hasMomo && (
            <a href={settings.donation_momo} target="_blank" rel="noreferrer" className="w-full flex items-center justify-center gap-2 py-2 bg-[#A50064] text-white rounded-lg hover:bg-[#8a0053] transition text-sm font-medium">
              MoMo
            </a>
          )}
          {hasCoffee && (
            <a href={settings.donation_buymeacoffee} target="_blank" rel="noreferrer" className="w-full flex items-center justify-center gap-2 py-2 bg-[#FFDD00] text-black rounded-lg hover:bg-[#e6c700] transition text-sm font-medium">
              <Coffee size={16} /> Buy Me A Coffee
            </a>
          )}
        </div>
      </div>
    );
  }

  return (
    <div id="main-donation" className="bg-white border-2 border-pink-100 rounded-2xl p-6 sm:p-8 my-10 shadow-sm relative overflow-hidden">
      <div className="absolute -top-10 -right-10 text-pink-50 opacity-50 transform rotate-12 pointer-events-none">
        <Heart size={200} className="fill-pink-100" />
      </div>
      
      <div className="relative z-10 text-center mb-8">
        <div className="w-16 h-16 bg-pink-100 text-pink-600 rounded-full flex items-center justify-center mx-auto mb-4">
          <Coffee size={32} />
        </div>
        <h2 className="text-2xl font-bold text-slate-800 mb-2">{settings.donation_title || "Ủng hộ tác giả"}</h2>
        <p className="text-slate-600 max-w-lg mx-auto">{settings.donation_message}</p>
      </div>

      <div className="max-w-md mx-auto">
        <div className="flex justify-center gap-2 mb-6">
          {hasBank && (
            <button 
              onClick={() => setActiveTab("bank")}
              className={`px-4 py-2 rounded-full text-sm font-medium transition ${activeTab === 'bank' ? 'bg-pink-600 text-white shadow-md' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
            >
              Chuyển khoản
            </button>
          )}
          {hasMomo && (
            <button 
              onClick={() => setActiveTab("momo")}
              className={`px-4 py-2 rounded-full text-sm font-medium transition ${activeTab === 'momo' ? 'bg-[#A50064] text-white shadow-md' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
            >
              MoMo
            </button>
          )}
          {hasCoffee && (
            <button 
              onClick={() => setActiveTab("coffee")}
              className={`px-4 py-2 rounded-full text-sm font-medium transition ${activeTab === 'coffee' ? 'bg-[#FFDD00] text-black shadow-md' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
            >
              Buy Me A Coffee
            </button>
          )}
        </div>

        <div className="bg-slate-50 border border-slate-100 rounded-2xl p-6 text-center">
          {activeTab === "bank" && hasBank && (
            <div className="animate-in fade-in slide-in-from-bottom-2 duration-300">
              <img 
                src={`https://img.vietqr.io/image/${settings.donation_bank_id}-${settings.donation_bank_account}-compact2.png`} 
                alt="VietQR" 
                className="w-48 h-48 mx-auto rounded-xl shadow-sm mb-4"
              />
              <div className="space-y-1">
                <p className="text-sm text-slate-500 uppercase font-semibold">{settings.donation_bank_id}</p>
                <p className="text-xl font-bold text-slate-800 tracking-wider">{settings.donation_bank_account}</p>
                <p className="text-sm font-medium text-slate-700 uppercase">{settings.donation_bank_name}</p>
              </div>
            </div>
          )}

          {activeTab === "momo" && hasMomo && (
            <div className="animate-in fade-in slide-in-from-bottom-2 duration-300 py-8">
              <a href={settings.donation_momo} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 px-8 py-4 bg-[#A50064] text-white rounded-xl hover:bg-[#8a0053] transition font-bold shadow-lg shadow-pink-500/30">
                Mở link ủng hộ qua MoMo
              </a>
            </div>
          )}

          {activeTab === "coffee" && hasCoffee && (
            <div className="animate-in fade-in slide-in-from-bottom-2 duration-300 py-8">
              <a href={settings.donation_buymeacoffee} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 px-8 py-4 bg-[#FFDD00] text-black rounded-xl hover:bg-[#e6c700] transition font-bold shadow-lg shadow-yellow-500/30">
                <Coffee size={24} /> Buy me a coffee
              </a>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
