import { NextAuthOptions } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import connectDB from "./mongodb";
import User from "@/models/User";
import bcrypt from "bcryptjs";
import AuditLog from "@/models/AuditLog";

export const authOptions: NextAuthOptions = {
  providers: [
    CredentialsProvider({
      name: "Credentials",
      credentials: {
        email: { label: "Email", type: "email", placeholder: "admin@example.com" },
        password: { label: "Password", type: "password" },
        token2fa: { label: "Mã 2FA (nếu có)", type: "text" },
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) return null;

        try {
          await connectDB();
          const user = await User.findOne({ email: credentials.email });

          if (!user) {
            console.log("[Auth] User not found:", credentials.email);
            return null;
          }

          if (!user.password) {
            console.log("[Auth] User has no password set");
            return null;
          }

          // Kiểm tra tài khoản bị khóa
          if (user.status === "banned") {
            console.log("[Auth] User is banned");
            return null;
          }

          const isPasswordValid = await bcrypt.compare(credentials.password, user.password);
          console.log("[Auth] Password valid:", isPasswordValid, "for:", credentials.email);

          if (!isPasswordValid) {
            try {
              await AuditLog.create({
                user: user._id,
                userName: user.name,
                action: "Đăng nhập thất bại (Sai mật khẩu)",
                type: "security",
                status: "failed",
              });
            } catch (e) { /* ignore audit log errors */ }
            return null;
          }

          // 2FA Verification
          if (user.isTwoFactorEnabled) {
            if (!credentials.token2fa) {
              throw new Error("2FA_REQUIRED");
            }

            const speakeasy = require("speakeasy");
            const verified = speakeasy.totp.verify({
              secret: user.twoFactorSecret,
              encoding: 'base32',
              token: credentials.token2fa,
              window: 1
            });

            if (!verified) {
              throw new Error("INVALID_2FA");
            }
          }

          // Log successful login
          try {
            await AuditLog.create({
              user: user._id,
              userName: user.name,
              action: "Đăng nhập hệ thống",
              type: "login",
              status: "success",
            });
          } catch (e) { /* ignore audit log errors */ }

          return {
            id: user._id.toString(),
            email: user.email,
            name: user.name,
            role: user.role,
          };
        } catch (error: any) {
          // Re-throw 2FA errors
          if (error.message === "2FA_REQUIRED" || error.message === "INVALID_2FA") {
            throw error;
          }
          console.error("[Auth] Error:", error);
          return null;
        }
      },
    }),
  ],
  session: {
    strategy: "jwt",
  },
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.role = (user as any).role;
        token.id = user.id;
        token.isPremium = (user as any).isPremium;
        token.premiumUntil = (user as any).premiumUntil;
      }
      
      // Tự động cập nhật quyền mới nhất từ database mỗi khi token được sử dụng
      if (token.id) {
        try {
          await connectDB();
          const dbUser = await User.findById(token.id).select("role status isPremium premiumUntil").lean();
          if (dbUser) {
            token.role = dbUser.role;
            token.isPremium = dbUser.isPremium;
            token.premiumUntil = dbUser.premiumUntil;
            // Nếu bị ban thì có thể ép đăng xuất hoặc xử lý ở middleware, tạm thời cập nhật role
          }
        } catch (e) {
          console.error("[Auth] Lỗi đồng bộ role:", e);
        }
      }
      
      return token;
    },
    async session({ session, token }) {
      if (token) {
        (session.user as any).role = token.role;
        (session.user as any).id = token.id;
        (session.user as any).isPremium = token.isPremium;
        (session.user as any).premiumUntil = token.premiumUntil;
      }
      return session;
    },
  },
  pages: {
    signIn: "/auth/signin",
  },
  secret: process.env.NEXTAUTH_SECRET || "super-secret-default-key-for-dev",
};
