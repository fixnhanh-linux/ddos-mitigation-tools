"use client";

import { useEditor, EditorContent, Editor } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import { 
  Bold, Italic, Strikethrough, Heading1, Heading2, 
  List, ListOrdered, Quote, Undo, Redo, Sparkles, Loader2 
} from "lucide-react";
import { useState } from 'react';

interface RichTextEditorProps {
  content: string;
  onChange: (html: string) => void;
}

const MenuBar = ({ editor }: { editor: Editor | null }) => {
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [aiResult, setAiResult] = useState<string | null>(null);

  if (!editor) {
    return null;
  }

  const handleAiAction = async (action: string) => {
    setIsAiLoading(true);
    setAiResult(null);
    try {
      const text = editor.getText();
      const res = await fetch('/api/ai/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, text })
      });
      const data = await res.json();
      if (data.success) {
        setAiResult(data.result);
      }
    } catch (e) {
      alert("Lỗi kết nối AI");
    }
    setIsAiLoading(false);
  };

  const applyAiResult = () => {
    if (aiResult) {
      editor.commands.setContent(aiResult);
      setAiResult(null);
    }
  };

  return (
    <>
      <div className="bg-slate-50 border-b border-slate-200 p-2 flex flex-wrap gap-1 items-center">
        <button
          type="button"
          onClick={() => editor.chain().focus().toggleBold().run()}
          className={`p-2 rounded ${editor.isActive("bold") ? "bg-slate-200 text-slate-800" : "text-slate-600 hover:bg-slate-100"}`}
          title="Bold"
        >
          <Bold size={18} />
        </button>
        <button
          type="button"
          onClick={() => editor.chain().focus().toggleItalic().run()}
          className={`p-2 rounded ${editor.isActive("italic") ? "bg-slate-200 text-slate-800" : "text-slate-600 hover:bg-slate-100"}`}
          title="Italic"
        >
          <Italic size={18} />
        </button>
        <button
          type="button"
          onClick={() => editor.chain().focus().toggleStrike().run()}
          className={`p-2 rounded ${editor.isActive("strike") ? "bg-slate-200 text-slate-800" : "text-slate-600 hover:bg-slate-100"}`}
          title="Strikethrough"
        >
          <Strikethrough size={18} />
        </button>
        
        <div className="w-px h-6 bg-slate-300 mx-1"></div>

        <button
          type="button"
          onClick={() => editor.chain().focus().toggleHeading({ level: 1 }).run()}
          className={`p-2 rounded ${editor.isActive("heading", { level: 1 }) ? "bg-slate-200 text-slate-800" : "text-slate-600 hover:bg-slate-100"}`}
          title="Heading 1"
        >
          <Heading1 size={18} />
        </button>
        <button
          type="button"
          onClick={() => editor.chain().focus().toggleHeading({ level: 2 }).run()}
          className={`p-2 rounded ${editor.isActive("heading", { level: 2 }) ? "bg-slate-200 text-slate-800" : "text-slate-600 hover:bg-slate-100"}`}
          title="Heading 2"
        >
          <Heading2 size={18} />
        </button>
        
        <div className="w-px h-6 bg-slate-300 mx-1"></div>

        <button
          type="button"
          onClick={() => editor.chain().focus().undo().run()}
          disabled={!editor.can().chain().focus().undo().run()}
          className="p-2 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition disabled:opacity-30"
          title="Hoàn tác (Ctrl+Z)"
        >
          <Undo size={18} />
        </button>
        <button
          type="button"
          onClick={() => editor.chain().focus().redo().run()}
          disabled={!editor.can().chain().focus().redo().run()}
          className="p-2 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition disabled:opacity-30"
          title="Làm lại (Ctrl+Y)"
        >
          <Redo size={18} />
        </button>

        <div className="w-px h-6 bg-slate-300 mx-1"></div>

        <button
          type="button"
          onClick={() => editor.chain().focus().toggleBulletList().run()}
          className={`p-2 rounded ${editor.isActive("bulletList") ? "bg-slate-200 text-slate-800" : "text-slate-600 hover:bg-slate-100"}`}
          title="Bullet List"
        >
          <List size={18} />
        </button>
        <button
          type="button"
          onClick={() => editor.chain().focus().toggleOrderedList().run()}
          className={`p-2 rounded ${editor.isActive("orderedList") ? "bg-slate-200 text-slate-800" : "text-slate-600 hover:bg-slate-100"}`}
          title="Ordered List"
        >
          <ListOrdered size={18} />
        </button>
        <button
          type="button"
          onClick={() => editor.chain().focus().toggleBlockquote().run()}
          className={`p-2 rounded ${editor.isActive("blockquote") ? "bg-slate-200 text-slate-800" : "text-slate-600 hover:bg-slate-100"}`}
          title="Quote"
        >
          <Quote size={18} />
        </button>

        <div className="w-px h-6 bg-slate-300 mx-1"></div>
        <div className="relative group">
          <button className="flex items-center gap-1.5 p-2 text-purple-600 hover:bg-purple-50 rounded-lg font-medium text-sm transition border border-purple-200">
            {isAiLoading ? <Loader2 size={16} className="animate-spin" /> : <Sparkles size={16} />}
            <span>Trợ lý AI</span>
          </button>
          <div className="absolute right-0 top-full mt-2 w-48 bg-white rounded-xl shadow-xl border border-slate-100 p-2 hidden group-hover:block z-50">
            <button onClick={() => handleAiAction('grammar')} className="w-full text-left px-3 py-2 text-sm text-slate-700 hover:bg-slate-50 rounded-lg">Sửa chính tả & Ngữ pháp</button>
            <button onClick={() => handleAiAction('summarize')} className="w-full text-left px-3 py-2 text-sm text-slate-700 hover:bg-slate-50 rounded-lg">Tóm tắt bài viết</button>
            <button onClick={() => handleAiAction('title_ideas')} className="w-full text-left px-3 py-2 text-sm text-slate-700 hover:bg-slate-50 rounded-lg">Gợi ý 3 Tiêu đề SEO</button>
          </div>
        </div>
      </div>

      {aiResult && (
        <div className="m-3 p-4 bg-purple-50 border border-purple-100 rounded-xl relative z-40">
          <div className="flex items-center gap-2 text-purple-800 font-semibold mb-2">
            <Sparkles size={16} /> AI đề xuất:
          </div>
          <div className="text-sm text-slate-700 whitespace-pre-wrap">{aiResult}</div>
          <div className="mt-3 flex gap-2">
            <button onClick={applyAiResult} className="px-3 py-1.5 bg-purple-600 text-white text-xs font-medium rounded-lg hover:bg-purple-700">Thay thế nội dung hiện tại</button>
            <button onClick={() => setAiResult(null)} className="px-3 py-1.5 bg-white text-slate-600 text-xs font-medium rounded-lg border border-slate-200 hover:bg-slate-50">Đóng</button>
          </div>
        </div>
      )}
    </>
  );
};

export default function RichTextEditor({ content, onChange }: RichTextEditorProps) {
  const editor = useEditor({
    extensions: [StarterKit],
    content,
    onUpdate: ({ editor }) => {
      onChange(editor.getHTML());
    },
    editorProps: {
      attributes: {
        class: "prose prose-sm sm:prose-base focus:outline-none min-h-[300px] max-w-none p-4",
      },
    },
  });

  return (
    <div className="border border-slate-200 rounded-lg bg-white relative z-0">
      <MenuBar editor={editor} />
      <EditorContent editor={editor} />
    </div>
  );
}
