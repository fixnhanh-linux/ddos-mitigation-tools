"use client";

import { useEffect } from "react";
import hljs from "highlight.js";
// Import theme
import "highlight.js/styles/atom-one-dark.css";

export default function SyntaxHighlighterHandler() {
  useEffect(() => {
    // Tìm tất cả các block code và highlight
    const blocks = document.querySelectorAll("pre code");
    blocks.forEach((block) => {
      // Chỉ highlight nếu chưa được highlight
      if (!block.classList.contains("hljs")) {
        hljs.highlightElement(block as HTMLElement);
      }
    });
    
    // Tùy chỉnh CSS của prose để không đụng độ với highlight.js
    const preTags = document.querySelectorAll("pre");
    preTags.forEach(pre => {
      pre.style.backgroundColor = "#282c34"; // Màu nền của atom-one-dark
      pre.style.padding = "1.5rem";
      pre.style.borderRadius = "0.75rem";
      pre.style.margin = "1.5rem 0";
    });
  }, []);

  return null;
}
