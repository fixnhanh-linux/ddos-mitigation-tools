import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Về chúng tôi | Tên Website",
  description: "Tìm hiểu về sứ mệnh và đội ngũ đằng sau Tên Website.",
};

export default function AboutPage() {
  return (
    <div className="max-w-4xl mx-auto py-12">
      <h1 className="text-4xl font-black text-slate-900 dark:text-white mb-6">Về chúng tôi</h1>
      <div className="prose prose-lg prose-indigo dark:prose-invert text-slate-600 dark:text-slate-300">
        <p>
          Chào mừng bạn đến với <strong>Tên Website</strong>! Đây là một nền tảng Tạp chí Số (Digital Magazine) hiện đại được xây dựng hoàn toàn bằng Next.js 15, MongoDB và TailwindCSS.
        </p>
        <p>
          Mục tiêu của chúng tôi là tạo ra một hệ sinh thái xuất bản nội dung siêu tốc độ, với giao diện sạch sẽ, chuyên nghiệp giúp độc giả tập trung 100% vào việc đọc, đồng thời cung cấp công cụ cực mạnh cho đội ngũ biên tập.
        </p>
        <p>
          Dự án này bao gồm:
        </p>
        <ul>
          <li>Trình soạn thảo văn bản nâng cao (Tiptap Rich Text Editor)</li>
          <li>Hệ thống phân quyền quản trị viên sâu (NextAuth)</li>
          <li>Giao diện tối giản chuẩn mực (Minimalist Design) với Dark Mode</li>
          <li>Hỗ trợ AI Text-to-Speech đọc báo tự động</li>
          <li>Tốc độ tải trang siêu tốc với kiến trúc App Router</li>
        </ul>
        <p className="mt-8 text-sm text-slate-400">
          <em>Được thiết kế và phát triển với niềm đam mê bất tận.</em>
        </p>
      </div>
    </div>
  );
}
