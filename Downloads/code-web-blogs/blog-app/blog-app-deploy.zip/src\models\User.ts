import mongoose, { Schema, Document } from "mongoose";

export interface IUser extends Document {
  name: string;
  email: string;
  password?: string;
  points: number;
  role: "super-admin" | "admin" | "editor" | "author" | "user";
  avatar?: string;
  phone?: string;
  bio?: string;
  status: "active" | "banned";
  twoFactorSecret?: string;
  isTwoFactorEnabled?: boolean;
  isPremium?: boolean;
  premiumUntil?: Date;
  createdAt: Date;
}

const UserSchema: Schema = new Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String }, // Hashed password, optional if OAuth
  points: { type: Number, default: 0 },
  role: { type: String, enum: ["super-admin", "admin", "editor", "author", "user"], default: "user" },
  avatar: { type: String, default: "" },
  phone: { type: String, default: "" },
  bio: { type: String, default: "" },
  status: { type: String, enum: ["active", "banned"], default: "active" },
  twoFactorSecret: { type: String },
  isTwoFactorEnabled: { type: Boolean, default: false },
  isPremium: { type: Boolean, default: false },
  premiumUntil: { type: Date },
  createdAt: { type: Date, default: Date.now },
});

export default mongoose.models.User || mongoose.model<IUser>("User", UserSchema);
