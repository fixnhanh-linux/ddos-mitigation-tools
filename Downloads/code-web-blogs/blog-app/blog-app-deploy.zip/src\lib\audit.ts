import connectDB from "./mongodb";
import AuditLog from "@/models/AuditLog";

interface LogActionParams {
  req: Request;
  userId?: string | null;
  userName?: string;
  action: string;
  type: "login" | "create" | "edit" | "delete" | "security" | "system";
  status?: "success" | "failed";
  details?: any;
}

export async function logAction({
  req,
  userId,
  userName = "Unknown",
  action,
  type,
  status = "success",
  details
}: LogActionParams) {
  try {
    await connectDB();
    
    // Lấy IP address
    let ip = "Unknown IP";
    const forwardedFor = req.headers.get("x-forwarded-for");
    if (forwardedFor) {
      ip = forwardedFor.split(',')[0].trim();
    } else {
      const realIp = req.headers.get("x-real-ip");
      if (realIp) ip = realIp;
    }

    await AuditLog.create({
      user: userId || null,
      userName,
      action,
      type,
      ip,
      status,
      details
    });
  } catch (error) {
    console.error("Failed to create audit log:", error);
  }
}
