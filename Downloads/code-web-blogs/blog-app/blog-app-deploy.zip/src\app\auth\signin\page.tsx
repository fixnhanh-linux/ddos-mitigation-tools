"use client";

import { useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Eye, EyeOff, Lock, Mail, ShieldCheck, ArrowRight, Loader2 } from "lucide-react";

export default function SignInPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [token2fa, setToken2fa] = useState("");
  const [show2FA, setShow2FA] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError("");

    try {
      const payload: any = { email, password, redirect: false };
      if (show2FA) payload.token2fa = token2fa;

      const res = await signIn("credentials", payload);

      if (res?.error) {
        if (res.error === "2FA_REQUIRED") {
          setShow2FA(true);
          setError("Vui lòng nhập mã xác thực 2 bước (Google Authenticator).");
        } else if (res.error === "INVALID_2FA") {
          setError("Mã xác thực không hợp lệ. Vui lòng thử lại.");
        } else {
          setError("Email hoặc mật khẩu không chính xác!");
        }
      } else {
        router.push("/dashboard");
        router.refresh();
      }
    } catch {
      setError("Đã xảy ra lỗi hệ thống.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex bg-slate-50">
      {/* Left panel – decorative */}
      <div className="hidden lg:flex lg:w-1/2 xl:w-3/5 bg-gradient-to-br from-indigo-600 via-indigo-700 to-purple-800 relative overflow-hidden items-center justify-center p-16">
        {/* Animated blobs */}
        <div className="absolute -top-32 -left-32 w-96 h-96 bg-white/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute -bottom-24 -right-24 w-80 h-80 bg-purple-400/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: "1s" }} />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-indigo-400/20 rounded-full blur-2xl" />

        {/* Content */}
        <div className="relative z-10 text-white max-w-md text-center space-y-8">
          {/* Grid icon decorative */}
          <div className="grid grid-cols-3 gap-3 w-fit mx-auto mb-8">
            {Array.from({ length: 9 }).map((_, i) => (
              <div
                key={i}
                className="w-8 h-8 rounded-lg bg-white/20 backdrop-blur-sm"
                style={{ animationDelay: `${i * 0.1}s` }}
              />
            ))}
          </div>
          <h2 className="text-4xl font-black leading-tight">
            Hệ thống quản trị<br />
            <span className="text-indigo-200">chuyên nghiệp</span>
          </h2>
          <p className="text-indigo-200 text-lg leading-relaxed">
            Quản lý bài viết, độc giả và nội dung website của bạn một cách thông minh và hiệu quả.
          </p>
          {/* Feature list */}
          <div className="space-y-3 text-left">
            {["Quản lý bài viết & media", "Phân tích lưu lượng truy cập", "Tích hợp SEO & Marketing"].map((f) => (
              <div key={f} className="flex items-center gap-3">
                <div className="w-5 h-5 bg-emerald-400 rounded-full flex items-center justify-center shrink-0">
                  <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <span className="text-indigo-100 text-sm font-medium">{f}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right panel – form */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 py-12 sm:px-12 lg:px-16">
        <div className="w-full max-w-md space-y-8">
          {/* Logo */}
          <div className="text-center space-y-2">
            <Link href="/" className="inline-block text-3xl font-black text-indigo-600 tracking-tighter hover:text-indigo-700 transition">
              Fix Nhanh.
            </Link>
            <h1 className="text-2xl font-bold text-slate-900 mt-4">Chào mừng trở lại!</h1>
            <p className="text-slate-500 text-sm">Đăng nhập để truy cập trang quản trị</p>
          </div>

          {/* Form card */}
          <div className="bg-white rounded-2xl shadow-xl shadow-slate-200/60 border border-slate-100 p-8 space-y-6">
            {/* Error */}
            {error && (
              <div className="flex items-start gap-3 bg-red-50 text-red-700 px-4 py-3 rounded-xl text-sm font-medium border border-red-100 animate-in slide-in-from-top duration-300">
                <svg className="w-4 h-4 mt-0.5 shrink-0" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                </svg>
                {error}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-5">
              {!show2FA ? (
                <>
                  {/* Email */}
                  <div className="space-y-1.5">
                    <label className="block text-sm font-semibold text-slate-700">Địa chỉ Email</label>
                    <div className="relative">
                      <Mail size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                      <input
                        type="email"
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full pl-10 pr-4 py-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent text-sm transition bg-white text-slate-900 placeholder:text-slate-400 hover:border-slate-300"
                        placeholder="admin@example.com"
                      />
                    </div>
                  </div>

                  {/* Password */}
                  <div className="space-y-1.5">
                    <label className="block text-sm font-semibold text-slate-700">Mật khẩu</label>
                    <div className="relative">
                      <Lock size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                      <input
                        type={showPassword ? "text" : "password"}
                        required
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="w-full pl-10 pr-12 py-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent text-sm transition bg-white text-slate-900 placeholder:text-slate-400 hover:border-slate-300"
                        placeholder="••••••••"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 transition"
                      >
                        {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                      </button>
                    </div>
                  </div>
                </>
              ) : (
                /* 2FA */
                <div className="space-y-3 animate-in slide-in-from-bottom duration-400">
                  <div className="flex items-center gap-3 p-4 bg-indigo-50 rounded-xl border border-indigo-100">
                    <ShieldCheck size={20} className="text-indigo-600 shrink-0" />
                    <div>
                      <p className="text-sm font-semibold text-indigo-900">Xác thực 2 bước</p>
                      <p className="text-xs text-indigo-600 mt-0.5">Mở Google Authenticator và nhập mã 6 số</p>
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <label className="block text-sm font-semibold text-slate-700">Mã xác thực (2FA)</label>
                    <input
                      type="text"
                      required
                      maxLength={6}
                      value={token2fa}
                      onChange={(e) => setToken2fa(e.target.value.replace(/\D/g, ""))}
                      className="w-full py-4 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-center font-mono text-3xl tracking-[0.5em] transition bg-white text-slate-900 placeholder:text-slate-300"
                      placeholder="------"
                      autoComplete="off"
                      autoFocus
                    />
                  </div>
                </div>
              )}

              {/* Submit */}
              <button
                type="submit"
                disabled={isLoading}
                className="w-full flex items-center justify-center gap-2 py-3.5 px-4 bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white font-bold rounded-xl shadow-lg shadow-indigo-500/30 transition-all hover:-translate-y-0.5 disabled:opacity-60 disabled:translate-y-0 disabled:cursor-not-allowed text-sm"
              >
                {isLoading ? (
                  <><Loader2 size={16} className="animate-spin" /> Đang xử lý...</>
                ) : show2FA ? (
                  <><ShieldCheck size={16} /> Xác thực & Đăng nhập</>
                ) : (
                  <>Đăng nhập <ArrowRight size={16} /></>
                )}
              </button>
            </form>
          </div>

          {/* Back link */}
          <p className="text-center text-sm text-slate-500">
            <Link href="/" className="text-indigo-600 font-semibold hover:text-indigo-700 transition">
              ← Quay lại trang chủ
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
