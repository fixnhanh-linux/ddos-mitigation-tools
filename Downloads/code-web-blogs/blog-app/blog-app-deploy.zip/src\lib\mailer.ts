import nodemailer from "nodemailer";

// Cấu hình Nodemailer sử dụng biến môi trường
// Trong thực tế, bạn cần thiết lập SMTP_USER và SMTP_PASS trong file .env
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || "smtp.gmail.com",
  port: Number(process.env.SMTP_PORT) || 587,
  secure: false, // true for 465, false for other ports
  auth: {
    user: process.env.SMTP_USER || "your-email@gmail.com", 
    pass: process.env.SMTP_PASS || "your-app-password",
  },
});

import Setting from "@/models/Setting";
import connectDB from "@/lib/mongodb";

export const sendEmailNotification = async (
  to: string,
  subject: string,
  html: string,
  fromName?: string
) => {
  try {
    if (!fromName) {
      await connectDB();
      const st = await Setting.findOne({ key: 'site_title' }).lean();
      fromName = (st?.value as string) || "Admin";
    }

    // Nếu chưa cấu hình biến môi trường, ta sẽ chỉ mock ra console thay vì gửi thật
    if (!process.env.SMTP_USER) {
      console.log("Mock Email Gửi đi:");
      console.log(`- Từ: ${fromName}`);
      console.log(`- Đến: ${to}`);
      console.log(`- Tiêu đề: ${subject}`);
      console.log(`- Nội dung: ${html}`);
      return true;
    }

    const info = await transporter.sendMail({
      from: `"${fromName}" <${process.env.SMTP_USER}>`,
      to,
      subject,
      html,
    });
    console.log("Đã gửi email: %s", info.messageId);
    return true;
  } catch (error) {
    console.error("Lỗi gửi email:", error);
    return false;
  }
};
