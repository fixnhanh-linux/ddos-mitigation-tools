import Link from "next/link";
import connectDB from "@/lib/mongodb";
import Post from "@/models/Post";
import { Edit, Trash2, Plus } from "lucide-react";
import AdminPostFilters from "@/components/AdminPostFilters";
import AdminPostsTable from "@/components/AdminPostsTable";
import Pagination from "@/components/Pagination";

import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

export default async function AdminPostsPage({ searchParams }: { searchParams: Promise<{ [key: string]: string | string[] | undefined }> }) {
  await connectDB();
  const session = await getServerSession(authOptions);
  const user = session?.user as any;
  const isAuthor = user?.role === "author";

  const resolvedParams = await searchParams;
  const search = typeof resolvedParams.search === "string" ? resolvedParams.search : "";
  const status = typeof resolvedParams.status === "string" ? resolvedParams.status : "all";
  const page = typeof resolvedParams.page === "string" ? parseInt(resolvedParams.page, 10) : 1;
  const limit = 5; // Để dễ thấy số trang
  const skip = (page - 1) * limit;

  // Filter posts based on role and query
  const query: any = {};
  if (isAuthor) {
    query.author = user?.id;
  }
  
  if (search) {
    query.title = { $regex: search, $options: "i" };
  }

  if (status !== "all") {
    query.status = status;
  }

  const totalPosts = await Post.countDocuments(query);
  const totalPages = Math.ceil(totalPosts / limit);

  const posts = await Post.find(query)
    .sort({ createdAt: -1 })
    .skip(skip)
    .limit(limit)
    .populate("author", "name")
    .lean();

  const serializedPosts = JSON.parse(JSON.stringify(posts));

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Quản lý Bài viết</h1>
        <Link href="/posts/new" className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-blue-700 transition">
          <Plus size={20} />
          <span>Viết bài mới</span>
        </Link>
      </div>

      <AdminPostFilters />

      <AdminPostsTable posts={serializedPosts} isAuthor={isAuthor} />

      {totalPages > 1 && (
        <div className="mt-8 mb-4">
          <Pagination totalPages={totalPages} />
          <div className="text-center mt-3 text-sm text-slate-500 font-medium">
            Hiển thị trang {page} / {totalPages} (Tổng cộng {totalPosts} bài viết)
          </div>
        </div>
      )}
    </div>
  );
}
