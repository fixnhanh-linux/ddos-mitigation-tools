"use client";

import { useState, useEffect, useRef } from "react";
import { useSession } from "next-auth/react";
import Link from "next/link";
import { Bell, MessageCircle } from "lucide-react";
import toast from "react-hot-toast";

export default function AdminHeader() {
  const { data: session } = useSession();
  const [unreadCount, setUnreadCount] = useState(0);
  const [showNotifications, setShowNotifications] = useState(false);
  const [contacts, setContacts] = useState<any[]>([]);
  const dropdownRef = useRef<HTMLDivElement>(null);
  
  // Lưu lại trạng thái tin nhắn trước đó để so sánh và hiện thông báo
  const prevContactsRef = useRef<any[]>([]);

  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setShowNotifications(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Fetch unread count regularly
  useEffect(() => {
    if (!session?.user) return;
    
    const fetchUnreadData = async () => {
      try {
        const res = await fetch("/api/messages/contacts");
        if (res.ok) {
          const data = await res.json();
          const newContacts = data.contacts || [];
          setContacts(newContacts);
          
          // Kiểm tra xem có tin nhắn nào mới không để bật Toast thông báo
          const prevContacts = prevContactsRef.current;
          if (prevContacts.length > 0) {
            newContacts.forEach((newContact: any) => {
              const oldContact = prevContacts.find((c: any) => c.id === newContact.id);
              // Nếu người này có thêm tin nhắn chưa đọc so với trước đó
              if (oldContact && newContact.unread > oldContact.unread) {
                toast(
                  (t) => (
                    <div className="flex flex-col gap-1 cursor-pointer" onClick={() => { window.location.href = "/messages"; toast.dismiss(t.id); }}>
                      <span className="font-semibold text-sm text-indigo-600">Tin nhắn từ {newContact.name}</span>
                      <span className="text-sm text-slate-700 truncate max-w-[200px]">{newContact.lastMessage}</span>
                    </div>
                  ),
                  { icon: '💬', duration: 5000 }
                );
              }
            });
          }
          prevContactsRef.current = newContacts;
          
          // Tính tổng số tin nhắn chưa đọc từ tất cả liên hệ
          const totalUnread = newContacts.reduce((sum: number, contact: any) => sum + (contact.unread || 0), 0);
          setUnreadCount(totalUnread);
        }
      } catch (error) {
        console.error("Lỗi lấy thông báo:", error);
      }
    };

    fetchUnreadData();
    // Tăng tốc độ check xuống 3 giây để có cảm giác "liền" tức thì
    const interval = setInterval(fetchUnreadData, 3000); 
    return () => clearInterval(interval);
  }, [session]);

  const unreadContacts = contacts.filter(c => c.unread > 0);

  return (
    <header className="bg-white border-b border-gray-200 pl-14 pr-8 py-4 flex justify-between items-center shrink-0 shadow-sm relative z-0">
      <h2 className="text-xl font-semibold text-gray-800">Xin chào, {session?.user?.name || "Admin"}!</h2>
      
      <div className="flex items-center gap-6">
        {/* Chuông thông báo */}
        <div className="relative" ref={dropdownRef}>
          <button 
            onClick={() => setShowNotifications(!showNotifications)}
            className={`relative p-2 rounded-full transition ${showNotifications ? 'bg-indigo-50 text-indigo-600' : 'text-slate-500 hover:bg-slate-100 hover:text-indigo-600'}`}
          >
            <Bell size={22} className={unreadCount > 0 ? "animate-pulse" : ""} />
            {unreadCount > 0 && (
              <span className="absolute top-0 right-0 bg-red-500 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center border-2 border-white">
                {unreadCount > 9 ? "9+" : unreadCount}
              </span>
            )}
          </button>

          {/* Dropdown */}
          {showNotifications && (
            <div className="absolute right-0 mt-2 w-80 bg-white rounded-xl shadow-xl border border-slate-100 overflow-hidden z-50">
              <div className="p-3 border-b border-slate-100 bg-slate-50 flex justify-between items-center">
                <h3 className="font-semibold text-slate-800 text-sm">Thông báo mới</h3>
                <span className="bg-indigo-100 text-indigo-600 text-xs font-bold px-2 py-0.5 rounded-full">{unreadCount}</span>
              </div>
              
              <div className="max-h-80 overflow-y-auto">
                {unreadContacts.length > 0 ? (
                  unreadContacts.map(contact => (
                    <Link 
                      href="/messages" 
                      key={contact.id}
                      onClick={() => setShowNotifications(false)}
                      className="flex items-start gap-3 p-3 hover:bg-slate-50 border-b border-slate-50 transition"
                    >
                      <div className="w-10 h-10 rounded-full bg-indigo-100 text-indigo-600 font-bold flex items-center justify-center shrink-0">
                        {contact.avatar}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex justify-between items-baseline mb-0.5">
                          <p className="font-medium text-sm text-slate-800 truncate">{contact.name}</p>
                          <span className="text-xs text-slate-400 shrink-0">{contact.time}</span>
                        </div>
                        <p className="text-xs text-slate-500 truncate">{contact.lastMessage}</p>
                      </div>
                      <div className="w-2 h-2 bg-red-500 rounded-full mt-2 shrink-0"></div>
                    </Link>
                  ))
                ) : (
                  <div className="p-6 text-center text-slate-500">
                    <MessageCircle size={32} className="mx-auto mb-2 opacity-20" />
                    <p className="text-sm">Bạn không có thông báo mới nào</p>
                  </div>
                )}
              </div>
              
              <Link 
                href="/messages"
                onClick={() => setShowNotifications(false)}
                className="block w-full text-center p-3 text-xs font-medium text-indigo-600 hover:bg-indigo-50 transition border-t border-slate-100"
              >
                Xem tất cả tin nhắn
              </Link>
            </div>
          )}
        </div>
        
        {/* Avatar */}
        <div className="w-10 h-10 rounded-full bg-blue-500 flex items-center justify-center text-white font-bold uppercase shadow-sm">
          {session?.user?.name?.charAt(0) || "A"}
        </div>
      </div>
    </header>
  );
}
