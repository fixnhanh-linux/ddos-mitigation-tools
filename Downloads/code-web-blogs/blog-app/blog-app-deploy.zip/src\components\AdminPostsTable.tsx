"use client";

import { useState } from "react";
import Link from "next/link";
import { Edit, Eye, Trash2 } from "lucide-react";
import PostModerationActions from "./PostModerationActions";
import DeletePostButton from "./DeletePostButton";
import { useRouter } from "next/navigation";

export default function AdminPostsTable({ posts, isAuthor }: { posts: any[]; isAuthor: boolean }) {
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [isDeleting, setIsDeleting] = useState(false);
  const router = useRouter();

  const handleSelectAll = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.checked) {
      setSelectedIds(posts.map((p) => p._id.toString()));
    } else {
      setSelectedIds([]);
    }
  };

  const handleSelectOne = (id: string) => {
    if (selectedIds.includes(id)) {
      setSelectedIds(selectedIds.filter((item) => item !== id));
    } else {
      setSelectedIds([...selectedIds, id]);
    }
  };

  const handleBulkDelete = async () => {
    if (selectedIds.length === 0) return;
    if (!confirm(`Bạn có chắc chắn muốn xoá ${selectedIds.length} bài viết đã chọn?`)) return;

    setIsDeleting(true);
    try {
      const res = await fetch("/api/posts/bulk-delete", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ids: selectedIds }),
      });
      if (res.ok) {
        setSelectedIds([]);
        router.refresh();
      } else {
        alert("Xoá thất bại!");
      }
    } catch (e) {
      alert("Lỗi kết nối.");
    }
    setIsDeleting(false);
  };

  return (
    <div>
      {selectedIds.length > 0 && (
        <div className="bg-blue-50 border border-blue-200 p-3 flex justify-between items-center rounded-t-xl">
          <span className="text-blue-800 font-medium">Đã chọn {selectedIds.length} bài viết</span>
          <button
            onClick={handleBulkDelete}
            disabled={isDeleting}
            className="bg-red-500 hover:bg-red-600 text-white px-4 py-1.5 rounded-lg text-sm font-medium disabled:opacity-50 flex items-center gap-2"
          >
            <Trash2 size={16} />
            {isDeleting ? "Đang xoá..." : "Xoá các mục đã chọn"}
          </button>
        </div>
      )}

      <div className={`bg-white shadow-sm border border-gray-100 overflow-x-auto ${selectedIds.length > 0 ? 'rounded-b-xl' : 'rounded-xl'}`}>
        <table className="w-full text-left border-collapse min-w-[800px]">
          <thead>
            <tr className="bg-gray-50 border-b border-gray-100 text-gray-600 text-sm">
              <th className="p-4 w-12 text-center">
                <input
                  type="checkbox"
                  className="rounded text-blue-600 focus:ring-blue-500 cursor-pointer"
                  checked={posts.length > 0 && selectedIds.length === posts.length}
                  onChange={handleSelectAll}
                />
              </th>
              <th className="p-4 font-semibold">Tiêu đề</th>
              <th className="p-4 font-semibold text-center">Lượt xem</th>
              <th className="p-4 font-semibold">Trạng thái</th>
              <th className="p-4 font-semibold">Ngày tạo</th>
              <th className="p-4 font-semibold text-right">Thao tác</th>
            </tr>
          </thead>
          <tbody>
            {posts.length === 0 ? (
              <tr>
                <td colSpan={6} className="p-8 text-center text-gray-500">
                  Chưa có bài viết nào phù hợp.
                </td>
              </tr>
            ) : (
              posts.map((post) => (
                <tr key={post._id.toString()} className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
                  <td className="p-4 text-center">
                    <input
                      type="checkbox"
                      className="rounded text-blue-600 focus:ring-blue-500 cursor-pointer"
                      checked={selectedIds.includes(post._id.toString())}
                      onChange={() => handleSelectOne(post._id.toString())}
                    />
                  </td>
                  <td className="p-4 font-medium text-gray-800">
                    <div>{post.title}</div>
                    {!isAuthor && post.author && (
                      <div className="text-xs text-gray-500 font-normal mt-1">bởi {post.author.name}</div>
                    )}
                  </td>
                  <td className="p-4 text-center">
                    <div className="flex items-center justify-center gap-1 text-slate-500 text-sm">
                      <Eye size={16} />
                      <span>{post.views || 0}</span>
                    </div>
                  </td>
                  <td className="p-4">
                    {(post.status === "published" || post.published === true) && (
                      <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-xs font-medium">Xuất bản</span>
                    )}
                    {post.status === "pending" && (
                      <span className="bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full text-xs font-medium">Chờ duyệt</span>
                    )}
                    {(post.status === "draft" || (!post.status && !post.published)) && (
                      <span className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-xs font-medium">Bản nháp</span>
                    )}
                    {post.status === "rejected" && (
                      <span className="bg-red-100 text-red-700 px-3 py-1 rounded-full text-xs font-medium" title={post.rejectionReason}>Từ chối</span>
                    )}
                  </td>
                  <td className="p-4 text-gray-500 text-sm">
                    {new Date(post.createdAt).toLocaleDateString("vi-VN")}
                  </td>
                  <td className="p-4 text-right">
                    <div className="flex justify-end items-center gap-3">
                      <Link href={`/posts/edit/${post._id}`} className="text-blue-500 hover:text-blue-700 p-1 hover:bg-blue-50 rounded">
                        <Edit size={18} />
                      </Link>
                      <DeletePostButton postId={post._id.toString()} />
                    </div>
                    {!isAuthor && post.status === "pending" && (
                      <div className="mt-2">
                         <PostModerationActions postId={post._id.toString()} status={post.status} />
                      </div>
                    )}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
